function funkcio(){
    var x = document.getElementById("feladat1").value;
    if (x == "10") {
        document.getElementById("megoldas1").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas1").innerHTML = "Helytelen";
    }
}

function funkcio2(){
    var x = document.getElementById("feladat2").value;
    if (x == "764") {
        document.getElementById("megoldas2").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas2").innerHTML = "Helytelen";
    }
}

function funkcio3(){
    var x = document.getElementById("feladat3").value;
    if (x == "1564") {
        document.getElementById("megoldas3").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas3").innerHTML = "Helytelen";
    }
}

function funkcio4(){
    var x = document.getElementById("feladat4").value;
    if (x == "87457") {
        document.getElementById("megoldas4").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas4").innerHTML = "Helytelen";
    }
}

function funkcio5(){
    var x = document.getElementById("feladat5").value;
    if (x == "6") {
        document.getElementById("megoldas5").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas5").innerHTML = "Helytelen";
    }
}

function funkcio6(){
    var x = document.getElementById("feladat6").value;
    if (x == "1112323") {
        document.getElementById("megoldas6").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas6").innerHTML = "Helytelen";
    }
}

function funkcio7(){
    var x = document.getElementById("feladat7").value;
    if (x == "99999112999") {
        document.getElementById("megoldas7").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas7").innerHTML = "Helytelen";
    }
}

function funkcio8(){
    var x = document.getElementById("feladat8").value;
    if (x == "755") {
        document.getElementById("megoldas8").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas8").innerHTML = "Helytelen";
    }
}

function funkcio9(){
    var x = document.getElementById("feladat9").value;
    if (x == "2683") {
        document.getElementById("megoldas9").innerHTML = "Helyes";
    }
    else {
        document.getElementById("megoldas9").innerHTML = "Helytelen";
    }
}